import{l as o,b as r}from"../chunks/B4G18dgV.js";export{o as load_css,r as start};
