import "clsx";
import { c as pop, p as push } from "../../../chunks/index.js";
function _page($$payload, $$props) {
  push();
  $$payload.out += `<section class="container svelte-vxruyk"><nav class="svelte-vxruyk"><div class="logo-box svelte-vxruyk"><a href="/"><img src="/logo.png" class="svelte-vxruyk"/></a></div></nav> <section class="login-img-section svelte-vxruyk"><img src="pawel-czerwinski-unsplash.jpg" class="svelte-vxruyk"/></section> <main class="svelte-vxruyk"><div id="login-col1"></div> <div id="login-col2" class="svelte-vxruyk"><div id="login-spacer" class="svelte-vxruyk"></div> <div id="login-form-section" class="svelte-vxruyk"><p id="login-intro" class="svelte-vxruyk">Welcome Back!</p> <h3 class="login-title svelte-vxruyk">Signin to Studyquiz</h3> <p class="svelte-vxruyk">For guest user, enter Guest with no password</p> <form class="svelte-vxruyk"><i class="fa fa-envelope icon"></i> <input name="user_name" type="input" placeholder="username" class="svelte-vxruyk"/> <input name="password" type="password" placeholder="password" class="svelte-vxruyk"/> <button class="svelte-vxruyk">Log in</button></form> <p class="svelte-vxruyk">Don't have an account? <a href="/signup">Sign up</a></p></div></div></main></section>`;
  pop();
}
export {
  _page as default
};
