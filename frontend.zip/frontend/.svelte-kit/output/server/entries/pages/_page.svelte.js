import { e as escape_html, c as pop, p as push } from "../../chunks/index.js";
import "clsx";
function _page($$payload, $$props) {
  push();
  let login = "";
  let user_name = "";
  if (user_name.length > 0) {
    login = user_name;
  } else {
    login = "Login";
  }
  $$payload.out += `<section class="container svelte-w82oib"><nav class="svelte-w82oib"><div class="logo-box svelte-w82oib"><a href="/"><img src="/logo.png" class="svelte-w82oib"/></a></div> <div class="menu-box svelte-w82oib"><a href="./login" class="svelte-w82oib">${escape_html(login)}</a></div></nav> <div id="notice" role="status" aria-live="polite" class="svelte-w82oib"><p class="svelte-w82oib"><strong>Prototype Notice:</strong> This website is a prototype.
    Account creation is disabled — please use the shared guest login to explore features.</p></div> <main class="svelte-w82oib"><div id="hero-spacer" class="svelte-w82oib"></div> <div id="hero" class="svelte-w82oib"><h1 class="svelte-w82oib">Study smarter Learn faster No need to memorise</h1> <p class="svelte-w82oib">Leverage AI to craft chapter-specific quizzes, enhance retention through spaced repetition, and ensure
    progress with follow-up scheduling .</p> <div class="button-container svelte-w82oib"><a href="/login" class="signup-button"><button class="svelte-w82oib">Login As a Guest</button></a></div> <div id="feature-grid" class="svelte-w82oib"><div id="feature-grid-inner" class="svelte-w82oib"><div id="col1" class="svelte-w82oib"><h3 class="svelte-w82oib">Spaced Repetition</h3><img src="spaced-repetition.png"/></div> <div id="col2"><h3>Shuffled Questions</h3><img src="shuffling.png"/></div> <div id="col3"><h3>Followup Schedule</h3><img src="followups-schedule.png"/></div> <div id="col4"><h3>Web &amp; API</h3><img src="web-api.png"/></div></div></div></div></main> <div id="sidebar1" class="svelte-w82oib"></div> <div id="sidebar2" class="svelte-w82oib"></div></section>`;
  pop();
}
export {
  _page as default
};
