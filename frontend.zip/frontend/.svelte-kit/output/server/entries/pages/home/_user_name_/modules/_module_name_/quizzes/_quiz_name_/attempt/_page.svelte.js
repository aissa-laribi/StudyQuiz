import { h as ensure_array_like, e as escape_html, k as attr_class, j as stringify, i as attr, c as pop, p as push } from "../../../../../../../../../chunks/index.js";
import "../../../../../../../../../chunks/client.js";
import { i as get } from "../../../../../../../../../chunks/exports.js";
import { p as page } from "../../../../../../../../../chunks/stores.js";
function _page($$payload, $$props) {
  push();
  const { module_name, quiz_name } = get(page).params;
  let questions = [];
  let answersByQuestionId = {};
  const moduleName = module_name;
  let selectedAnswers = {};
  const each_array = ensure_array_like(questions);
  $$payload.out += `<section class="container svelte-pfplr"><nav class="svelte-pfplr"><div class="logo-box svelte-pfplr"><a href="/"><img src="/logo.png" class="svelte-pfplr"/></a></div> <div class="menu-box svelte-pfplr"><p class="profile svelte-pfplr"></p></div></nav> <main class="svelte-pfplr"><div id="spacer" class="svelte-pfplr"><h3 class="svelte-pfplr">${escape_html(moduleName)} - ${escape_html(quiz_name)}</h3></div> <div id="question-index" class="svelte-pfplr"><p class="svelte-pfplr">Page</p> <div id="question-index-content" class="svelte-pfplr"><!--[-->`;
  for (let i = 0, $$length = each_array.length; i < $$length; i++) {
    let question = each_array[i];
    $$payload.out += `<div${attr_class(`question-check-box ${stringify(selectedAnswers[question.id] ? "answered" : "unanswered")}`, "svelte-pfplr")}>`;
    if (selectedAnswers[question.id]) {
      $$payload.out += "<!--[-->";
      $$payload.out += `ANSWER SAVED`;
    } else {
      $$payload.out += "<!--[!-->";
    }
    $$payload.out += `<!--]--></div>`;
  }
  $$payload.out += `<!--]--></div></div> <div id="question-page" class="svelte-pfplr">`;
  {
    $$payload.out += "<!--[-->";
    const each_array_1 = ensure_array_like(questions);
    $$payload.out += `<form class="svelte-pfplr"><!--[-->`;
    for (let $$index_2 = 0, $$length = each_array_1.length; $$index_2 < $$length; $$index_2++) {
      let question = each_array_1[$$index_2];
      let i = $$index_2;
      const each_array_2 = ensure_array_like(answersByQuestionId[question.id] || []);
      $$payload.out += `<div class="svelte-pfplr"><p class="svelte-pfplr">Question ${escape_html(i + 1)}: ${escape_html(question.question_name)}</p> <!--[-->`;
      for (let j = 0, $$length2 = each_array_2.length; j < $$length2; j++) {
        let answer = each_array_2[j];
        $$payload.out += `<input type="radio"${attr("id", `q${question.id}-a${j}`)}${attr("name", `question-${question.id}`)}${attr("value", answer.id)}${attr("checked", selectedAnswers[question.id] === answer.id, true)} class="svelte-pfplr"/> <label${attr("for", `q${question.id}-a${j}`)} class="svelte-pfplr">${escape_html(answer.answer_name)}</label><br class="svelte-pfplr"/>`;
      }
      $$payload.out += `<!--]--></div>`;
    }
    $$payload.out += `<!--]--> <div id="form-button-section" class="svelte-pfplr"><button type="submit" class="svelte-pfplr"><p class="svelte-pfplr">Submit</p></button></div></form>`;
  }
  $$payload.out += `<!--]--> `;
  {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--></div></main> <div id="sidebar1" class="svelte-pfplr"></div> <div id="sidebar2" class="svelte-pfplr"></div></section>`;
  pop();
}
export {
  _page as default
};
