import { d as copy_payload, f as assign_payload, c as pop, p as push, h as ensure_array_like, e as escape_html, i as attr, j as stringify } from "../../../../../../chunks/index.js";
import "../../../../../../chunks/client.js";
function _page($$payload, $$props) {
  push();
  let quizzes = [];
  let followups = [];
  let user_name = "";
  const imageIndex = localStorage.getItem(`imgModuleIndex`);
  const moduleName = localStorage.getItem(`moduleName`);
  let $$settled = true;
  let $$inner_payload;
  function $$render_inner($$payload2) {
    const each_array = ensure_array_like(quizzes);
    const each_array_1 = ensure_array_like(followups.slice(0, 3));
    $$payload2.out += `<section class="container svelte-101l539"><nav class="svelte-101l539"><div class="logo-box svelte-101l539"><a href="/"><img src="/logo.png" class="svelte-101l539"/></a></div> <div class="menu-box svelte-101l539"><p class="profile svelte-101l539">${escape_html(user_name)}</p></div></nav> <main class="svelte-101l539"><div id="spacer" class="svelte-101l539"><div class="overlay svelte-101l539"></div> <img${attr("src", `/modules/${stringify(imageIndex)}.jpg`)} alt="Module Banner" class="svelte-101l539"/> <h3 class="svelte-101l539">${escape_html(moduleName)}</h3></div> <div id="col-modules" class="svelte-101l539"><div id="my-modules" class="svelte-101l539"><h2 class="svelte-101l539">Quizzes <button id="new-module-button" class="svelte-101l539"><svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-plus svelte-101l539"><path stroke="none" d="M0 0h24v24H0z" fill="none" class="svelte-101l539"></path><path d="M12 5l0 14" class="svelte-101l539"></path><path d="M5 12l14 0" class="svelte-101l539"></path></svg> <span class="tooltiptext svelte-101l539">Add a New Quiz</span></button></h2></div> <div id="modules-container" class="svelte-101l539"><!--[-->`;
    for (let i = 0, $$length = each_array.length; i < $$length; i++) {
      let quiz = each_array[i];
      $$payload2.out += `<div class="module-box svelte-101l539"><h3 class="header-quiz svelte-101l539"><p class="quiz-title svelte-101l539">${escape_html(quiz.quiz_name)}</p> <button id="attempt-button" class="svelte-101l539">Attempt</button> <button id="update-button" class="svelte-101l539">Update</button></h3> <p class="svelte-101l539">Created: ${escape_html(new Date(quiz.created_at).toLocaleString())} - <strong>Last score: ${escape_html(quiz.last_score)}%</strong> <br/> Attempts: ${escape_html(quiz.repetitions)} - <strong>Next Due Date: ${escape_html(new Date(quiz.next_due).toLocaleString())}</strong> - Updated: ${escape_html(new Date(quiz.next_due).toLocaleString())}</p></div>`;
    }
    $$payload2.out += `<!--]--></div></div> <div id="col-quizzes" class="svelte-101l539"><div id="followups-container" class="svelte-101l539"><div id="upcoming-quizzes" class="svelte-101l539"><h2 class="svelte-101l539">Upcoming Quizzes</h2></div> <!--[-->`;
    for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
      let followup = each_array_1[$$index_1];
      $$payload2.out += `<a class="followup-box svelte-101l539"${attr("href", `/home/${user_name}/modules/${followup.module.module_name}/quizzes/${followup.quiz.quiz_name}/attempt`)}><div class="quiz-icon svelte-101l539"><svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-clipboard-clock-icon lucide-clipboard-clock"><path d="M16 14v2.2l1.6 1"></path><path d="M16 4h2a2 2 0 0 1 2 2v.832"></path><path d="M8 4H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h2"></path><circle cx="16" cy="16" r="6"></circle><rect x="8" y="2" width="8" height="4" rx="1"></rect></svg></div> <div class="quiz-details svelte-101l539"><p class="quiz-title svelte-101l539">${escape_html(followup.module.module_name)} — ${escape_html(followup.quiz.quiz_name)}</p> <p class="quiz-due-date svelte-101l539">Due: ${escape_html(new Date(followup.followup_due_date).toLocaleDateString())}</p></div></a>`;
    }
    $$payload2.out += `<!--]--></div></div> `;
    {
      $$payload2.out += "<!--[!-->";
    }
    $$payload2.out += `<!--]--></main> <div id="sidebar1" class="svelte-101l539"></div> <div id="sidebar2" class="svelte-101l539"></div></section>`;
  }
  do {
    $$settled = true;
    $$inner_payload = copy_payload($$payload);
    $$render_inner($$inner_payload);
  } while (!$$settled);
  assign_payload($$payload, $$inner_payload);
  pop();
}
export {
  _page as default
};
