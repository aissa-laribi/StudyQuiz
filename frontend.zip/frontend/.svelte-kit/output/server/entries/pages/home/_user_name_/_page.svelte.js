import { d as copy_payload, f as assign_payload, c as pop, p as push, h as ensure_array_like, e as escape_html, i as attr, j as stringify } from "../../../../chunks/index.js";
function _page($$payload, $$props) {
  push();
  let modules = [];
  let followups = [];
  let user_name = "";
  let $$settled = true;
  let $$inner_payload;
  function $$render_inner($$payload2) {
    const each_array = ensure_array_like(modules);
    const each_array_1 = ensure_array_like(followups.slice(0, 3));
    $$payload2.out += `<section class="container svelte-18yqkjg"><nav class="svelte-18yqkjg"><div class="logo-box svelte-18yqkjg"><a href="/"><img src="/logo.png" class="svelte-18yqkjg"/></a></div> <div class="menu-box svelte-18yqkjg"><p class="profile svelte-18yqkjg">${escape_html(user_name)}</p></div></nav> <main class="svelte-18yqkjg"><div id="spacer" class="svelte-18yqkjg"></div> <div id="col-modules" class="svelte-18yqkjg"><div id="my-modules" class="svelte-18yqkjg"><h2 class="svelte-18yqkjg">My Modules <button id="new-module-button" class="svelte-18yqkjg"><svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-plus svelte-18yqkjg"><path stroke="none" d="M0 0h24v24H0z" fill="none" class="svelte-18yqkjg"></path><path d="M12 5l0 14" class="svelte-18yqkjg"></path><path d="M5 12l14 0" class="svelte-18yqkjg"></path></svg> <span class="tooltiptext svelte-18yqkjg">Add a New Module</span></button></h2></div> <div id="modules-container" class="svelte-18yqkjg"><!--[-->`;
    for (let i = 0, $$length = each_array.length; i < $$length; i++) {
      let module = each_array[i];
      $$payload2.out += `<div class="module-box svelte-18yqkjg"><img${attr("src", `/modules/${stringify(i + 1)}.jpg`)} class="svelte-18yqkjg"/> <p class="svelte-18yqkjg"><a${attr("href", `/home/${user_name}/modules/${module}`)} class="svelte-18yqkjg">${escape_html(module)}</a></p></div>`;
    }
    $$payload2.out += `<!--]--></div></div> <div id="col-quizzes" class="svelte-18yqkjg"><div id="followups-container" class="svelte-18yqkjg"><div id="upcoming-quizzes" class="svelte-18yqkjg"><h2 class="svelte-18yqkjg">Upcoming Quizzes</h2></div> <!--[-->`;
    for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
      let followup = each_array_1[$$index_1];
      $$payload2.out += `<a class="followup-box svelte-18yqkjg"${attr("href", `/home/${user_name}/modules/${followup.module.module_name}/quizzes/${followup.quiz.quiz_name}/attempt`)}><div class="quiz-icon svelte-18yqkjg"><svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-clipboard-clock-icon lucide-clipboard-clock"><path d="M16 14v2.2l1.6 1"></path><path d="M16 4h2a2 2 0 0 1 2 2v.832"></path><path d="M8 4H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h2"></path><circle cx="16" cy="16" r="6"></circle><rect x="8" y="2" width="8" height="4" rx="1"></rect></svg></div> <div class="quiz-details svelte-18yqkjg"><p class="quiz-title svelte-18yqkjg">${escape_html(followup.module.module_name)} — ${escape_html(followup.quiz.quiz_name)}</p> <p class="quiz-due-date svelte-18yqkjg">Due: ${escape_html(new Date(followup.followup_due_date).toLocaleDateString())}</p></div></a>`;
    }
    $$payload2.out += `<!--]--></div> `;
    {
      $$payload2.out += "<!--[!-->";
    }
    $$payload2.out += `<!--]--></div></main> <div id="sidebar1" class="svelte-18yqkjg"></div> <div id="sidebar2" class="svelte-18yqkjg"></div></section>`;
  }
  do {
    $$settled = true;
    $$inner_payload = copy_payload($$payload);
    $$render_inner($$inner_payload);
  } while (!$$settled);
  assign_payload($$payload, $$inner_payload);
  pop();
}
export {
  _page as default
};
