import { d as copy_payload, f as assign_payload, c as pop, p as push, h as ensure_array_like, e as escape_html, i as attr, j as stringify } from "../../../../../../../../chunks/index.js";
import { p as page } from "../../../../../../../../chunks/stores.js";
import { i as get } from "../../../../../../../../chunks/exports.js";
function _page($$payload, $$props) {
  push();
  const { module_name, quiz_name } = get(page).params;
  let questions = [];
  let user_name = "";
  const imageIndex = localStorage.getItem(`imgModuleIndex`);
  let quizData = "";
  let $$settled = true;
  let $$inner_payload;
  function $$render_inner($$payload2) {
    const each_array = ensure_array_like(questions);
    $$payload2.out += `<section class="container svelte-r3s0tw"><nav class="svelte-r3s0tw"><div class="logo-box svelte-r3s0tw"><a href="/"><img src="/logo.png" class="svelte-r3s0tw"/></a></div> <div class="menu-box svelte-r3s0tw"><p class="profile svelte-r3s0tw">${escape_html(user_name)}</p></div></nav> <main class="svelte-r3s0tw"><div id="spacer" class="svelte-r3s0tw"><div class="overlay svelte-r3s0tw"></div> <img${attr("src", `/modules/${stringify(imageIndex)}.jpg`)} alt="Module Banner" class="svelte-r3s0tw"/> <h3 class="svelte-r3s0tw">${escape_html(module_name)} - ${escape_html(quiz_name)}</h3></div> <div id="col-modules" class="svelte-r3s0tw"><div id="my-modules" class="svelte-r3s0tw"><h2 class="svelte-r3s0tw">Questions <button id="new-module-button" class="svelte-r3s0tw"><svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-plus svelte-r3s0tw"><path stroke="none" d="M0 0h24v24H0z" fill="none" class="svelte-r3s0tw"></path><path d="M12 5l0 14" class="svelte-r3s0tw"></path><path d="M5 12l14 0" class="svelte-r3s0tw"></path></svg> <span class="tooltiptext svelte-r3s0tw">Add a New Question</span></button></h2></div> <div id="modules-container" class="svelte-r3s0tw"><!--[-->`;
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      let question = each_array[$$index];
      $$payload2.out += `<div class="module-box svelte-r3s0tw"><p class="svelte-r3s0tw">${escape_html(question.question_name)}</p></div>`;
    }
    $$payload2.out += `<!--]--></div></div> <div id="col-quizzes" class="svelte-r3s0tw"><div id="followups-container" class="svelte-r3s0tw"><div id="upcoming-quizzes" class="svelte-r3s0tw"><h2 class="svelte-r3s0tw">Import Quiz from ChatGPT</h2> <ol class="svelte-r3s0tw"><li class="svelte-r3s0tw"><strong class="svelte-r3s0tw">Get your slides ready</strong></li> <li class="svelte-r3s0tw"><strong class="svelte-r3s0tw">Copy and paste the following prompt<strong class="svelte-r3s0tw"><br/> <pre style="background:#f4f4f4; padding:0.6em; border-radius:0.4em;">
Generate 20 quiz questions from these slides in JSON format for studyquiz.co. 
Each question must include 5 answer choices, 2 plausible distractors, and only 1 correct answer.
      </pre></strong></strong></li> <li class="svelte-r3s0tw"><strong class="svelte-r3s0tw">Copy ChatGPT’s reply</strong></li> <li class="svelte-r3s0tw"><strong class="svelte-r3s0tw">Paste it below and click “Upload Quiz”</strong></li></ol> <p style="font-size: 0.9em; color: #666;" class="svelte-r3s0tw">Example of what the answer should look like:</p> <pre style="background:#f8f8f8; padding:0.75em; border-radius:0.5em; font-size: 0.9em;">
  "questions": [
    {
      "name": "What does CPU stand for?",
      "answers": [
        {"name": "Central Processing Unit", "correct": true},
        {"name": "Computer Power Unit", "correct": false},
        {"name": "Core Programming Utility", "correct": false},
        ...
      ]
    }
  ]

</pre> <textarea rows="10" style="width: 100%; margin-top: 1em; font-family: monospace;" placeholder="Paste your JSON here...">`;
    const $$body = escape_html(quizData);
    if ($$body) {
      $$payload2.out += `${$$body}`;
    }
    $$payload2.out += `</textarea> <button style="margin-top: 0.5em; background-color: green; color: white; padding: 0.5em 1em;">Upload Quiz</button></div></div></div> `;
    {
      $$payload2.out += "<!--[!-->";
    }
    $$payload2.out += `<!--]--></main> <div id="sidebar1" class="svelte-r3s0tw"></div> <div id="sidebar2" class="svelte-r3s0tw"></div></section>`;
  }
  do {
    $$settled = true;
    $$inner_payload = copy_payload($$payload);
    $$render_inner($$inner_payload);
  } while (!$$settled);
  assign_payload($$payload, $$inner_payload);
  pop();
}
export {
  _page as default
};
