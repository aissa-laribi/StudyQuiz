export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["favicon.png","followups-schedule.png","logo.png","modules/1.jpg","modules/10.jpg","modules/11.jpg","modules/12.jpg","modules/2.jpg","modules/3.jpg","modules/4.jpg","modules/5.jpg","modules/6.jpg","modules/7.jpg","modules/8.jpg","modules/9.jpg","pawel-czerwinski-unsplash.jpg","shared.css","shuffling.png","spaced-repetition.png","web-api.png"]),
	mimeTypes: {".png":"image/png",".jpg":"image/jpeg",".css":"text/css"},
	_: {
		client: {start:"_app/immutable/entry/start.Jf60cA2h.js",app:"_app/immutable/entry/app.BIoT0vSh.js",imports:["_app/immutable/entry/start.Jf60cA2h.js","_app/immutable/chunks/B4G18dgV.js","_app/immutable/chunks/C_MIBbDk.js","_app/immutable/chunks/BvIhHQ4S.js","_app/immutable/entry/app.BIoT0vSh.js","_app/immutable/chunks/C_MIBbDk.js","_app/immutable/chunks/Bpws6mPE.js","_app/immutable/chunks/DNdElgf3.js","_app/immutable/chunks/DVyJjfmc.js","_app/immutable/chunks/BvIhHQ4S.js","_app/immutable/chunks/DeJqrW6u.js","_app/immutable/chunks/BOUcqU7c.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
		nodes: [
			__memo(() => import('./nodes/0.js')),
			__memo(() => import('./nodes/1.js')),
			__memo(() => import('./nodes/2.js')),
			__memo(() => import('./nodes/3.js')),
			__memo(() => import('./nodes/4.js')),
			__memo(() => import('./nodes/5.js')),
			__memo(() => import('./nodes/6.js')),
			__memo(() => import('./nodes/7.js'))
		],
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 2 },
				endpoint: null
			},
			{
				id: "/home/[user_name]",
				pattern: /^\/home\/([^/]+?)\/?$/,
				params: [{"name":"user_name","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,], errors: [1,], leaf: 3 },
				endpoint: null
			},
			{
				id: "/home/[user_name]/modules/[module_name]",
				pattern: /^\/home\/([^/]+?)\/modules\/([^/]+?)\/?$/,
				params: [{"name":"user_name","optional":false,"rest":false,"chained":false},{"name":"module_name","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,], errors: [1,], leaf: 4 },
				endpoint: null
			},
			{
				id: "/home/[user_name]/modules/[module_name]/quizzes/[quiz_name]",
				pattern: /^\/home\/([^/]+?)\/modules\/([^/]+?)\/quizzes\/([^/]+?)\/?$/,
				params: [{"name":"user_name","optional":false,"rest":false,"chained":false},{"name":"module_name","optional":false,"rest":false,"chained":false},{"name":"quiz_name","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,], errors: [1,], leaf: 5 },
				endpoint: null
			},
			{
				id: "/home/[user_name]/modules/[module_name]/quizzes/[quiz_name]/attempt",
				pattern: /^\/home\/([^/]+?)\/modules\/([^/]+?)\/quizzes\/([^/]+?)\/attempt\/?$/,
				params: [{"name":"user_name","optional":false,"rest":false,"chained":false},{"name":"module_name","optional":false,"rest":false,"chained":false},{"name":"quiz_name","optional":false,"rest":false,"chained":false}],
				page: { layouts: [0,], errors: [1,], leaf: 6 },
				endpoint: null
			},
			{
				id: "/login",
				pattern: /^\/login\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 7 },
				endpoint: null
			}
		],
		prerendered_routes: new Set([]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();
