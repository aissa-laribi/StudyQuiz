

export const index = 6;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/home/_user_name_/modules/_module_name_/quizzes/_quiz_name_/attempt/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/6.4ZY6E8Yj.js","_app/immutable/chunks/DVyJjfmc.js","_app/immutable/chunks/C_MIBbDk.js","_app/immutable/chunks/Cb1hpuVz.js","_app/immutable/chunks/BvIhHQ4S.js","_app/immutable/chunks/Bpws6mPE.js","_app/immutable/chunks/DNdElgf3.js","_app/immutable/chunks/DeJqrW6u.js","_app/immutable/chunks/B7dK8FH5.js","_app/immutable/chunks/B4G18dgV.js","_app/immutable/chunks/C22zTtkO.js"];
export const stylesheets = ["_app/immutable/assets/6.RjRSbV8t.css"];
export const fonts = [];
