

export const index = 3;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/home/_user_name_/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/3.VsE8fdGi.js","_app/immutable/chunks/DVyJjfmc.js","_app/immutable/chunks/C_MIBbDk.js","_app/immutable/chunks/Cb1hpuVz.js","_app/immutable/chunks/BvIhHQ4S.js","_app/immutable/chunks/Bpws6mPE.js","_app/immutable/chunks/DNdElgf3.js","_app/immutable/chunks/DeJqrW6u.js","_app/immutable/chunks/B7dK8FH5.js","_app/immutable/chunks/DOxJNaXz.js","_app/immutable/chunks/BOUcqU7c.js"];
export const stylesheets = ["_app/immutable/assets/3.-6JPF1ss.css"];
export const fonts = [];
