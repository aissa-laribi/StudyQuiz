

export const index = 5;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/home/_user_name_/modules/_module_name_/quizzes/_quiz_name_/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/5.DiOQ8Glp.js","_app/immutable/chunks/DVyJjfmc.js","_app/immutable/chunks/C_MIBbDk.js","_app/immutable/chunks/Cb1hpuVz.js","_app/immutable/chunks/BvIhHQ4S.js","_app/immutable/chunks/Bpws6mPE.js","_app/immutable/chunks/DNdElgf3.js","_app/immutable/chunks/DeJqrW6u.js","_app/immutable/chunks/B7dK8FH5.js","_app/immutable/chunks/B4G18dgV.js","_app/immutable/chunks/DOxJNaXz.js","_app/immutable/chunks/BOUcqU7c.js","_app/immutable/chunks/C22zTtkO.js"];
export const stylesheets = ["_app/immutable/assets/5.pE7bG6lE.css"];
export const fonts = [];
