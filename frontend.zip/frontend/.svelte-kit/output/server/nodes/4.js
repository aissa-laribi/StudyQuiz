

export const index = 4;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/home/_user_name_/modules/_module_name_/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/4.DFU5DI9y.js","_app/immutable/chunks/DVyJjfmc.js","_app/immutable/chunks/C_MIBbDk.js","_app/immutable/chunks/Cb1hpuVz.js","_app/immutable/chunks/BvIhHQ4S.js","_app/immutable/chunks/Bpws6mPE.js","_app/immutable/chunks/DNdElgf3.js","_app/immutable/chunks/DeJqrW6u.js","_app/immutable/chunks/B7dK8FH5.js","_app/immutable/chunks/DOxJNaXz.js","_app/immutable/chunks/BOUcqU7c.js","_app/immutable/chunks/B4G18dgV.js"];
export const stylesheets = ["_app/immutable/assets/4.RjU6Om9m.css"];
export const fonts = [];
