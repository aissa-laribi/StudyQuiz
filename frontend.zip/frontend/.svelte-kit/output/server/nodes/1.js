

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.D_eXfCNX.js","_app/immutable/chunks/DVyJjfmc.js","_app/immutable/chunks/C_MIBbDk.js","_app/immutable/chunks/Cb1hpuVz.js","_app/immutable/chunks/Bpws6mPE.js","_app/immutable/chunks/DNdElgf3.js","_app/immutable/chunks/B4G18dgV.js","_app/immutable/chunks/BvIhHQ4S.js"];
export const stylesheets = [];
export const fonts = [];
