

export const index = 0;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/layout.svelte.js')).default;
export const imports = ["_app/immutable/nodes/0.BI8RoJ8D.js","_app/immutable/chunks/DVyJjfmc.js","_app/immutable/chunks/C_MIBbDk.js","_app/immutable/chunks/DOxJNaXz.js"];
export const stylesheets = [];
export const fonts = [];
